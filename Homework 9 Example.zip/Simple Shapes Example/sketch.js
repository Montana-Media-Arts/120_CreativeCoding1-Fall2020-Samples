function setup() {
    createCanvas(600, 400);
  }
  
  function draw() {
    background(120,32,29);
    fill(123,23,129);
    circle(50,100,100);
    fill(123,123,129);
    square(200,200,50);
    fill(23,223,29);
    ellipse(250,300,100,50);
    fill(223,123,29);
    rect(350,300,150,75);
    fill(0);
    textSize(32);
    text("Here is some text", 250,195);
  }